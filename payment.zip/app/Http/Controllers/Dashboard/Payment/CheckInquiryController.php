<?php

namespace App\Http\Controllers\Dashboard\Payment;

use App\CheckInquiry;
use Illuminate\Http\Request;

class CheckInquiryController extends \App\Http\Controllers\Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('dashboard.payment.chequeInquiry');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CheckInquiry  $checkInquiry
     * @return \Illuminate\Http\Response
     */
    public function show(CheckInquiry $checkInquiry)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CheckInquiry  $checkInquiry
     * @return \Illuminate\Http\Response
     */
    public function edit(CheckInquiry $checkInquiry)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CheckInquiry  $checkInquiry
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CheckInquiry $checkInquiry)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CheckInquiry  $checkInquiry
     * @return \Illuminate\Http\Response
     */
    public function destroy(CheckInquiry $checkInquiry)
    {
        //
    }
}
