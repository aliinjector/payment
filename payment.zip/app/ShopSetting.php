<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
class ShopSetting extends Model
{
    //
}
