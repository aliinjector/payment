<div class="tt-top-panel d-none-print" id="js-tt-top-panel">
    <div class="container">
        <div class="tt-row">
            <div class="tt-description">{{ $special_text }}</div>
            <button class="tt-btn-close"></button>
        </div>
    </div>
</div>
