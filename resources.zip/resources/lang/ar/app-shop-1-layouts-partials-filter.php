<?php
return array(
    /*
    |--------------------------------------------------------------------------
    | Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the default error messages used by
    | the validator class. Some of these rules have multiple versions such
    | as the size rules. Feel free to tweak each of these messages here.
    |
    */
    "filterType"         => "تصفية حسب نوع المنتج",
    "filterTypeItem1"         => "جميع",
    "filterTypeItem2"         => "جسدي",
    "filterTypeItem3"         => " ملف",
    "filterTypeItem4"         => "الخدمات",
    "filterPrice"         => "تصفية حسب السعر",
    "filterColor"         => "تصفية حسب اللون",
    "dasteBandiHa"         => "فرز النتائج",



);
