<?php
return array(
    /*
    |--------------------------------------------------------------------------
    | Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the default error messages used by
    | the validator class. Some of these rules have multiple versions such
    | as the size rules. Feel free to tweak each of these messages here.
    |
    */
    "filterType"         => "فیلتر بر اساس نوع کالا",
    "filterTypeItem1"         => "همه",
    "filterTypeItem2"         => "فیزیکی",
    "filterTypeItem3"         => " فایل",
    "filterTypeItem4"         => "خدماتی",
    "filterPrice"         => "فیلتر بر اساس قیمت کالا",
    "filterColor"         => "فیلتر بر اساس رنگ کالا",
    "dasteBandiHa"         => "دسته بندی نتایج",



);
